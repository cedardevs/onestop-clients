from onestop_client.consumer import consume
